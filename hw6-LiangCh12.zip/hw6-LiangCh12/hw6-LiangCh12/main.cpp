#include <iostream>
#include <string>
#include <vector>
using namespace std;


// EX06_01 Liang 12.2: Linear Search
template <typename T> //Using template to substitute list and key (something within array)
int linearSearch(const T list[], T key, int arraySize)
{
	for (int i = 0; i < arraySize; i++)
	{
		if (key == list[i])
			return i;
	}
	return -1;
}

// EX06_02 Liang 12.4: Is Sorted?
template <typename X> // Using a basic template to substitute the list
bool isSorted(const X list[], int arraySize)
{
	for (int i = 1; i < arraySize; i++)
	{
		if (list[i] < list[i - 1]) // If current element is smaller than previous, return false
		{
			cout << "False \n";
			return false;
		}
		else 
		{
			cout << "True \n";
			return true;
		}
	}
}

// EX06_04 Liang 12.20: Shuffle Vector Class
template <typename V>
void shuffle(vector<V> &v)
{
	int size = v.size();
	V tempNums; // Implements placeholders for inputted numbers
	int randm = 0;
	for (int i = 0; i < size; i++)
	{
		randm = rand() % (i + 1); 
		tempNums = v[i]; // Assigns the temporary number into an array
		v[i] = v[randm];
		v[randm] = tempNums; // Randomize the numbers
	}
}


int main()
{
	
	int arraySize = 3; // Implements size as 3
	int arrayI[3] = { 1, 2, 3 };
	double arrayD[3] = { 0.1, 2.2, 4.4 };
	string arrayS[3] = { "M", "T", "V" };
	string findStrg = "M"; // Implements the string to "M"

	// EX06_01 Liang 12.2: Linear Search
	linearSearch(arrayI, 3, arraySize); // Calls the int array
	linearSearch(arrayD, 2.2, arraySize); // Calls the double array
	linearSearch(arrayS, findStrg, arraySize); // Calls the string array

	// EX06_02 Liang 12.4: Is Sorted?
	isSorted(arrayI, arraySize); // Calls the int array
	isSorted(arrayD, arraySize); // Calls the double array
	isSorted(arrayS, arraySize); // Calls the string array

	// EX06_03 Liang 12.8: Implement Vector Class
	vector<int> intVect(); // Empty vector
	vector<double> doubleVect(4); // Vector with initial size and default values
	vector<string> stringVect(2, "replaceNew"); // Vector with initial size and specific values
	stringVect.push_back("new"); // Appends element
	stringVect.pop_back(); // Removes previous element
	int vectSize = stringVect.size(); // 
	bool empty = doubleVect.empty();
	vector<string> stringVectSub(4, "replaceAnother");
	stringVectSub.swap(stringVect);
	stringVect.clear();

	// EX06_04 Liang 12.20: Shuffle Vector Class
	vector<int> v1(10); // Vector size hold 10 integers
	cout << "Please enter 10 integers: " << endl;
	for (int size = 0; size < 10; size++)
		cin >> v1[size]; // Store the integers into places in size
	cout << endl;
	shuffle(v1); // Shuffle the numbers
	cout << "Shuffled integers: " << endl;
	for (int size = 0; size < 10; size++)
		cout << v1[size] << endl; // Makes sure that all places are filled and displayed

	return 0;
}